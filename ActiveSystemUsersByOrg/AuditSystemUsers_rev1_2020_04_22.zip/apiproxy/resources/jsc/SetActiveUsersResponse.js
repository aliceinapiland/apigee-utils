var response = context.getVariable("response.content");

var auditRecord = JSON.parse(response).auditRecord;

var uniqueUsers = [];
for(i = 0; i< auditRecord.length; i++){    
    if(uniqueUsers.indexOf(auditRecord[i].user) === -1){
        uniqueUsers.push(auditRecord[i].user);        
    }        
}

var responsePayload = {};

responsePayload.org = context.getVariable("org");
responsePayload.start = context.getVariable("start");
responsePayload.end = context.getVariable("end");
responsePayload.numberOfActiveSystemUsers = uniqueUsers.length;
responsePayload.systemUsers = uniqueUsers;


context.setVariable("response.content", JSON.stringify(responsePayload));
context.setVariable("response.header.content-type", "application/json");