var startTime = JSON.parse(context.getVariable("request.queryparam.startTime"));
var endTime = JSON.parse(context.getVariable("request.queryparam.endTime"));

context.setVariable("start", startTime);
context.setVariable("end", endTime);

var startTimestamp = new Date(startTime).getTime();
var endTimestamp = new Date(endTime).getTime();

context.setVariable("request.queryparam.startTime", JSON.stringify(startTimestamp));
context.setVariable("request.queryparam.endTime", JSON.stringify(endTimestamp));
context.setVariable("request.queryparam.expand", true);
context.setVariable("request.header.content-type", "application/octet-stream");
context.setVariable("org", context.getVariable("request.queryparam.org"));
